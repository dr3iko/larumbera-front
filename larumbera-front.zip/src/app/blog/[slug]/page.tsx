import { notFound } from 'next/navigation';

// 1. Función para obtener los datos de UN SOLO post, usando su slug
async function getSinglePost(slug: string) {
  const query = `
    query GetPostBySlug($id: ID!) {
      post(id: $id, idType: SLUG) {
        title
        content
        date
        author {
          node {
            name
          }
        }
        featuredImage {
          node {
            sourceUrl
            altText
          }
        }
      }
    }
  `;

  const variables = {
    id: slug,
  };

  try {
    const res = await fetch('https://larumbera.xyz/back/graphql', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Basic ${btoa(process.env.WP_USER + ':' + process.env.WP_PASSWORD)}`
      },
      body: JSON.stringify({ query, variables }),
      next: { revalidate: 60 },
    });
    
    const json = await res.json();
    return json.data.post;

  } catch (error) {
    console.error("Error al obtener el post:", error);
    return null;
  }
}

// 2. El componente de la página recibe los `params` de la URL
export default async function SinglePostPage({ params }: { params: { slug: string } }) {
  const post = await getSinglePost(params.slug);

  // Si WordPress no devuelve un post (ej. slug no existe), muestra la página 404 de Next.js
  if (!post) {
    notFound();
  }

  return (
    <article className="max-w-4xl mx-auto px-4 py-8">
      <h1 className="text-3xl md:text-5xl font-extrabold text-rumbera-blue mb-4">{post.title}</h1>
      <div className="text-gray-500 mb-8">
        <span>Por {post.author.node.name}</span> | 
        <span> Publicado el {new Date(post.date).toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
      </div>
      
      {/* Aquí renderizamos el HTML del contenido que viene de WordPress.
          'dangerouslySetInnerHTML' es seguro aquí porque confiamos en el contenido
          que nosotros mismos escribimos en nuestro WordPress. */}
      <div
        className="prose lg:prose-xl max-w-none"
        dangerouslySetInnerHTML={{ __html: post.content }}
      />
    </article>
  );
}

// Pro Tip: Para que la clase `prose` funcione y estilice tu artículo
// automáticamente, instala el plugin de tipografía de Tailwind:
// 1. En la terminal: npm install -D @tailwindcss/typography
// 2. En tailwind.config.ts, añade `require('@tailwindcss/typography')` al array de plugins.